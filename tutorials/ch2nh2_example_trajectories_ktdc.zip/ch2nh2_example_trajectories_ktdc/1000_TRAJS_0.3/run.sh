#!/bin/bash
# Set the base directory where all the subfolders are located
BASE_DIR="/data/cat/ws/rhba420e-e-mace-workspace/emace/CH2NH2+_TRAJS/1000_TRAJS_0.3"

# Set the path to the test_sharc.py file that you want to copy
SOURCE_FILE="/data/cat/ws/rhba420e-e-mace-workspace/emace/CH2NH2+_TRAJS/1000_TRAJS_0.3/sharc_run.py"

# Traverse through each subfolder
for dir in "$BASE_DIR"/*; do
    # Check if it's a directory
    if [ -d "$dir" ]; then
        # Copy the test_sharc.py file into the subfolder
        cp "$SOURCE_FILE" "$dir/"

        # Enter the directory
        cd "$dir"

        # Run the test_sharc.py script
        python3 sharc_run.py

        # Output a message indicating that the file has been executed
        echo "Executed test_sharc.py in $dir"

        # Go back to the base directory
        cd "$BASE_DIR"
    fi
done

