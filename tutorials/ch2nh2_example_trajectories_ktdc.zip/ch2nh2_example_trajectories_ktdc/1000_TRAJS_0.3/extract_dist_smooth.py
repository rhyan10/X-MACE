import os
import numpy as np
import matplotlib.pyplot as plt

# Define the root directory containing the folders
root_directory = '.'

# Initialize an empty dictionary to store states from each folder
all_states = []

# Iterate through each folder in the root directory
for folder_name in os.listdir(root_directory):
    folder_path = os.path.join(root_directory, folder_name)
    
    # Check if the path is a directory
    if os.path.isdir(folder_path):
        # Define the path to the output.lis file within the folder
        lis_file_path = os.path.join(folder_path, 'output.lis')
        #print(lis_file_path) 
        # Check if the output.lis file exists in the folder
        if os.path.exists(lis_file_path):
            # Initialize a list to store the states from this specific output.lis
            states = np.ones(201) 
            j = 0
            # Read the file and extract the state for each time step
            with open(lis_file_path, 'r') as file:
                for line in file:
                    # Skip header lines or any line that doesn't contain data
                    if line.startswith('#') or line.strip() == "":
                        continue
                    # Split the line into columns based on whitespace
                    columns = line.split()
                    # Extract the state, which is the 3rd column in each row
                    state = int(columns[2])
                    # Append the state to the list
                    states[j] = state
                    j+=1
            # Store the list of states in the dictionary with the folder name as the key
            all_states.append(np.array(states))
                #print(len(states))

for state in all_states:
    print(state.shape)

all_states = np.stack(all_states).T

# Step 1: Count the occurrences of 1, 2, and 3 at each time step
count_1 = np.sum(all_states == 1, axis=-1)
count_2 = np.sum(all_states == 2, axis=-1)
count_3 = np.sum(all_states == 3, axis=-1)

print(count_1)
print(count_2)
print(count_3)

# Step 2: Calculate the percentage of each element at each time step
total_elements = all_states.shape[-1]  # 3825 in this case
percentage_1 = (count_1 / total_elements) * 100
percentage_2 = (count_2 / total_elements) * 100
percentage_3 = (count_3 / total_elements) * 100

# print(percentage_1)
# print(percentage_2)
# print(percentage_3)

# Plotting the percentages over time
import scipy.ndimage
import matplotlib as mpl
mpl.rcParams['font.size'] = 20  # Base font size
mpl.rcParams['axes.labelsize'] = 20  # Axis labels
mpl.rcParams['xtick.labelsize'] = 20  # Tick labels
mpl.rcParams['ytick.labelsize'] = 20
mpl.rcParams['legend.fontsize'] = 20
mpl.rcParams['figure.titlesize'] = 20
mpl.rcParams['font.family'] = 'sans-serif'
mpl.rcParams['font.sans-serif'] = ['Arial']  # Use Arial or a similar font

time_steps = np.arange(all_states.shape[0]) * 0.5
color_blind_palette = ['#13678A', '#45C4B0', '#9AEBA3']

# Smooth the data
percentage_1_smooth = scipy.ndimage.gaussian_filter1d(percentage_1, sigma=2)
percentage_2_smooth = scipy.ndimage.gaussian_filter1d(percentage_2, sigma=2)
percentage_3_smooth = scipy.ndimage.gaussian_filter1d(percentage_3, sigma=2)

plt.figure(figsize=(8.5, 6), dpi=300)
plt.plot(time_steps, percentage_1_smooth, label="$S_0$", color=color_blind_palette[0], linewidth=2)
plt.plot(time_steps, percentage_2_smooth, label="$S_1$", color=color_blind_palette[1], linewidth=2)
plt.plot(time_steps, percentage_3_smooth, label="$S_2$", color=color_blind_palette[2], linewidth=2)
plt.xlabel("Time (fs)")
plt.ylabel("Population")
plt.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
plt.legend()
plt.tight_layout()
plt.savefig('population.png', dpi=300, bbox_inches='tight')  # Save as high-resolution PNG

#plt.figure(figsize=(10, 6))
#plt.plot(time_steps, percentage_1, label='State 1', marker='o')
#plt.plot(time_steps, percentage_2, label='State 2', marker='s')
#plt.plot(time_steps, percentage_3, label='State 3', marker='^')

#plt.title('Percentage of Each State Over Time')
#plt.xlabel('Time Step')
#plt.ylabel('Percentage (%)')
#plt.legend()
#plt.grid(True)
#plt.savefig("populations.png", dpi=300, bbox_inches='tight')
#plt.show
