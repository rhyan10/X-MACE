import sys, os
import mace
from mace.calculators.sharcinterface import SHARC_NN

models = ["/home/rhyan/E-MACE/methylenimmonium_0.85_duation.model"]
th = None # for active learning, e.g., {'energy': 0.004}
nn = SHARC_NN(modelpath=models, # path to NN models
   atoms="CNHHHH", # symbols of sample molecule
   n_states={'n_singlets': 3, 'n_triplets': 0}, # dict of state numbers
   thresholds=th,
   cutoff=10.0, # for building representation
   nac_key="smooth_nacs", # model trained on smoothed nacs
   properties=['energy','forces','smooth_nacs'] # properties predicted by NN
)
nn.run_sharc("./input",0)
