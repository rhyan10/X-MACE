import ase.io
#from mace.calculators import MACECalculator
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

# === Constants ===
HA_PER_EV = 1 / 27.211386245988  # Hartree per eV
DEBYE_TO_AU = 1 / 2.541746       # atomic units per Debye

def broaden_spectrum(energies_eV, mu_debye, sigma_eV=0.05, E_min=None, E_max=None, points=2000):
    """
    Build and return an absorption spectrum by Gaussian broadening of stick transitions.
    
    Parameters:
    - energies_eV: array of excitation energies (eV)
    - mu_debye:    array of transition dipole magnitudes (Debye)
    - sigma_eV:    Gaussian broadening width (eV)
    - E_min, E_max: energy range for the grid (eV). Defaults to min/max of energies ±0.5 eV
    - points:      number of points in the output spectrum
    
    Returns:
    - E_grid:      energy grid (eV)
    - spectrum:    normalized absorption intensity
    """
    # Convert to atomic units
    E_ha = energies_eV * HA_PER_EV
    mu_au = mu_debye * DEBYE_TO_AU
    
    # Oscillator strengths
    f = (2/3) * E_ha * (mu_au ** 2)
    
    # Define grid
    if E_min is None: E_min = energies_eV.min() - 0.5
    if E_max is None: E_max = energies_eV.max() + 0.5
    E_grid = np.linspace(E_min, E_max, points)
    
    # Gaussian kernel
    def gauss(x, sigma):
        return np.exp(-0.5 * (x / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))
    
    # Build spectrum
    S = np.zeros_like(E_grid)
    for Ei, fi in zip(energies_eV, f):
        S += fi * gauss(E_grid - Ei, sigma_eV)
    
    # Normalize
    return E_grid, S / S.max()

# === Set up MACE calculator ===
# calc = MACECalculator(
#     model_paths="/home/rhyan/E-MACE/propene_dipole_duation.model",
#     n_energies=3,
#     device="cuda"
# )

# === Load structures ===
db = ase.io.read("c3h6.xyz", ":1000")

energies = []
energies_ref = []
dipoles = []
dipoles_ref = []

# === Compute energies & dipoles ===
for mol in tqdm(db):
    # calc.calculate(mol)
    # res = calc.results
    # res_ref = mol.info#["REF_energy"]
    # energies.append(res["energy"][0][1] - res["energy"][0][0])            # in eV
    energies_ref.append(mol.info["REF_energy"][0][1] - mol.info["REF_energy"][0][0])
    #dipoles.append(mol.info["REdipoles"][0][1])      # magnitude of transition dipole
    dipoles_ref.append(mol.info["REF_dipoles"][1])

# energies = np.array(energies)
# dipoles = np.array(dipoles)
# dipole_mags = np.linalg.norm(dipoles, axis=1)  # shape (N,)
# # === Build & plot spectrum ===
# E_grid, spectrum = broaden_spectrum(energies, dipole_mags, sigma_eV=0.1)

energies_ref = np.array(energies_ref)
dipoles_ref = np.array(dipoles_ref)
dipole_mags_ref = np.linalg.norm(dipoles_ref, axis=1)  # shape (N,)
# === Build & plot spectrum ===
E_grid_ref, spectrum_ref = broaden_spectrum(energies_ref, dipole_mags_ref, sigma_eV=0.1)

#plt.plot(E_grid, spectrum)
plt.plot(E_grid_ref, spectrum_ref, '--')
plt.xlabel("Energy (eV)")
plt.ylabel("Normalized Oscillator")
plt.tight_layout()
plt.savefig("absorption_spectrum.png", dpi=300)   # ← saves the figure
plt.show()

