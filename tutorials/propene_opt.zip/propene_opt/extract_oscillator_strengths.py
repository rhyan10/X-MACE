import ase.io
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import numpy as np
from ase import Atoms
import pickle

HA_PER_EV = 1 / 27.211386245988  # Hartree per eV
DEBYE_TO_AU = 1 / 2.541746       # atomic units per Debye

def broaden_spectrum(energies_eV, f, sigma_eV=0.05, E_min=None, E_max=None, points=2000):
    """
    Build and return an absorption spectrum by Gaussian broadening of stick transitions.
    
    Parameters:
    - energies_eV: array of excitation energies (eV)
    - mu_debye:    array of transition dipole magnitudes (Debye)
    - sigma_eV:    Gaussian broadening width (eV)
    - E_min, E_max: energy range for the grid (eV). Defaults to min/max of energies ±0.5 eV
    - points:      number of points in the output spectrum
    
    Returns:
    - E_grid:      energy grid (eV)
    - spectrum:    normalized absorption intensity
    """
    
    # Define grid
    if E_min is None: E_min = energies_eV.min() - 0.5
    if E_max is None: E_max = energies_eV.max() + 0.5
    E_grid = np.linspace(E_min, E_max, points)
    
    # Gaussian kernel
    def gauss(x, sigma):
        return np.exp(-0.5 * (x / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))
    
    # Build spectrum
    S = np.zeros_like(E_grid)
    for Ei, fi in zip(energies_eV, f):
        S += fi * gauss(E_grid - Ei, sigma_eV)
    
    # Normalize
    return E_grid, S / S.max()

def osc_compute(energies_eV, mu_debye):

    # Convert to atomic units
    E_ha = energies_eV * HA_PER_EV
    mu_au = np.sum((mu_debye * DEBYE_TO_AU)**2)
    # Oscillator strengths
    f = (2/3) * E_ha * mu_au
    
    return f

db = ase.io.read("test_osc_data.xyz", ":")

E_diff1 = []
osc_vals1 = []

for mol in db:
    E_diff1.append(mol.info["REF_energy"][0][0])
    osc_vals1.append(mol.info["REF_energy"][0][3])

E_grid1, spectrum1 = broaden_spectrum(np.array(E_diff1), np.array(osc_vals1), sigma_eV=0.1)

with open('deltaE_osc.pkl', 'rb') as f:
    values = pickle.load(f)

E_diff2 = []
osc_vals2 = []

for val in values:
    E_diff2.append(val[0][0]) #mol.info["REF_energy"][0][0])
    osc_vals2.append(val[0][3])#mol.info["REF_energy"][0][3])

E_grid2, spectrum2 = broaden_spectrum(np.array(E_diff2), np.array(osc_vals2), sigma_eV=0.1)

plt.plot(E_grid1, spectrum1, label='Reference')
plt.plot(E_grid2, spectrum2, label='Predicted', linestyle='--')
plt.xlabel("Energy (eV)")
plt.ylabel("Normalized Oscillator")
plt.tight_layout()
plt.savefig("absorption_spectrum.png", dpi=300)   # ← saves the figure
plt.show()