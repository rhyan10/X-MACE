#!/usr/bin/env python3
"""
parse_sharc_initconds.py

Reads a SHARC initial‐conditions file (with repeated
blocks of “Index …”, “Atoms”, lines of element+coords, “States …”),
and returns a list of ASE Atoms objects containing just the
symbols and positions for each geometry.
"""
import sys
from ase import Atoms

def parse_sharc_initconds(path):
    structures = []
    symbols = []
    positions = []
    reading_atoms = False

    with open(path, 'r') as f:
        for raw in f:
            line = raw.strip()
            if not line:
                # blank line: skip
                continue

            if line.startswith("Index"):
                # Starting a new block: if we have an unfinished molecule, save it
                if symbols:
                    structures.append(Atoms(symbols=symbols, positions=positions))
                    symbols, positions = [], []
                reading_atoms = False
                continue

            if line == "Atoms":
                # Next lines are element + data
                reading_atoms = True
                continue

            if line.startswith("States"):
                # End of atom block
                reading_atoms = False
                continue

            if reading_atoms:
                parts = line.split()
                # Expect at least 5 columns: symbol, something, x y z, ...
                if len(parts) >= 5:
                    symbol = parts[0]
                    x, y, z = map(float, parts[2:5])
                    symbols.append(symbol)
                    positions.append((x*0.529177249, y*0.529177249, z*0.529177249))
                else:
                    # Unexpected format—skip
                    continue

        # After loop, catch the last geometry
        if symbols:
            structures.append(Atoms(symbols=symbols, positions=positions))

    return structures

def main():
    if len(sys.argv) != 2:
        print("Usage: python parse_sharc_initconds.py <initconds_file>")
        sys.exit(1)

    path = sys.argv[1]
    geoms = parse_sharc_initconds(path)
    import ase.io
    ase.io.write("structs.xyz", geoms)
    print(f"Parsed {len(geoms)} structures from '{path}'.")
    # Example: print first geometry summary
    if geoms:
        print("First structure:")
        print(geoms[0])
    else:
        print("No structures found—check format!")

if __name__ == "__main__":
    main()

