import ase.io
from mace.calculators import MACECalculator
import numpy as np
import matplotlib.pyplot as plt

calc = MACECalculator(model_paths="/home/rhyan/E-MACE/propene_dipole_duation.model", n_energies=3, device="cuda")

db = ase.io.read("structs.xyz",":")

x = []
y = []

for mol in db:
    calc.calculate(mol)
    results = calc.results
    pos = mol.get_positions()
    energy = results["energy"]
    dipole = results["dipoles"][0][3]
    print(energy)
    print(dipole)
