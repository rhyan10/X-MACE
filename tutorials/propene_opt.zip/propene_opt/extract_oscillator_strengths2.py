import ase.io
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import numpy as np
from ase import Atoms

HA_PER_EV = 1 / 27.211386245988  # Hartree per eV
DEBYE_TO_AU = 1 / 2.541746       # atomic units per Debye

def broaden_spectrum(energies_eV, f, sigma_eV=0.05, E_min=None, E_max=None, points=2000):
    """
    Build and return an absorption spectrum by Gaussian broadening of stick transitions.
    
    Parameters:
    - energies_eV: array of excitation energies (eV)
    - mu_debye:    array of transition dipole magnitudes (Debye)
    - sigma_eV:    Gaussian broadening width (eV)
    - E_min, E_max: energy range for the grid (eV). Defaults to min/max of energies ±0.5 eV
    - points:      number of points in the output spectrum
    
    Returns:
    - E_grid:      energy grid (eV)
    - spectrum:    normalized absorption intensity
    """
    
    # Define grid
    if E_min is None: E_min = energies_eV.min() - 0.5
    if E_max is None: E_max = energies_eV.max() + 0.5
    E_grid = np.linspace(E_min, E_max, points)
    
    # Gaussian kernel
    def gauss(x, sigma):
        return np.exp(-0.5 * (x / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))
    
    # Build spectrum
    S = np.zeros_like(E_grid)
    for Ei, fi in zip(energies_eV, f):
        S += fi * gauss(E_grid - Ei, sigma_eV)
    
    # Normalize
    return E_grid, S / S.max()

def osc_compute(energies_eV, mu_debye):

    # Convert to atomic units
    E_ha = energies_eV * HA_PER_EV
    mu_au = np.sum((mu_debye * DEBYE_TO_AU)**2)
    # Oscillator strengths
    f = (2/3) * E_ha * mu_au
    
    return f

db = ase.io.read("c3h6.xyz", ":1000")

all_atoms = []

for mol in db:
    diff1 = mol.info["REF_energy"][0][1] - mol.info["REF_energy"][0][0]
    diff2 = mol.info["REF_energy"][0][2] - mol.info["REF_energy"][0][0]
    diff3 = mol.info["REF_energy"][0][2] - mol.info["REF_energy"][0][1]
    mu1 = mol.info["REF_dipoles"][1]
    mu2 = mol.info["REF_dipoles"][2]
    mu3 = mol.info["REF_dipoles"][4]
    osc1 = osc_compute(diff1, mu1)
    osc2 = osc_compute(diff2, mu2)
    osc3 = osc_compute(diff3, mu3)
    vals = np.array([diff1,diff2,diff3, osc1, osc2, osc3])
    vals = vals.reshape((1,6))
    atoms = Atoms(numbers=mol.numbers, positions=mol.positions)
    atoms.info["REF_energy"] = vals
    all_atoms.append(atoms)

np.random.seed(42)
np.random.shuffle(all_atoms)
ase.io.write("train_osc_data.xyz", all_atoms[:int(0.7*len(all_atoms))])
ase.io.write("test_osc_data.xyz", all_atoms[int(0.7*len(all_atoms)):])